package interfaces;

public interface Nameable {
    String getName();
}