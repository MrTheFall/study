package characters;

public class Alice extends Character {
    public Alice(String name){
        super(name);
    }
}