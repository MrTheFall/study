package interfaces;

public interface Thinkable {
    void think(String thought);
}